//
// Created by Hassan on 27/02/2020.
//
#include <stdio.h>
int main (void){
printf("Programming is fun");
return 0;
}

